<?php

return [
    'secret' => env('RECAPTCHA_SECRETKEY'),
    'sitekey' => env('RECAPTCHA_SITEKEY'),
];
