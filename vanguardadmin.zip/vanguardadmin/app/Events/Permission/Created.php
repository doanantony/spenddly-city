<?php

namespace Vanguard\Events\Permission;

class Created extends PermissionEvent {}