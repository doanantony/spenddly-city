<?php

namespace Vanguard\Events\Role;

class PermissionsUpdated {}