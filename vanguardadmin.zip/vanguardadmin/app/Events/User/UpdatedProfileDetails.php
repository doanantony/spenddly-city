<?php

namespace Vanguard\Events\User;

class UpdatedProfileDetails {}
