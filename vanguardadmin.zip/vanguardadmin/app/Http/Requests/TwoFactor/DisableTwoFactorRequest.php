<?php

namespace Vanguard\Http\Requests\TwoFactor;

use Vanguard\Http\Requests\Request;
use Vanguard\Repositories\User\UserRepository;
use Vanguard\User;

class DisableTwoFactorRequest extends TwoFactorRequest
{
}
