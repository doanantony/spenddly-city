<div class="d-flex align-items-start px-4 p-4 navbar-item">
    <img src="<?php echo e($announcement->creator->present()->avatar); ?>" width="50" height="50"
         class="rounded-circle img-responsive mr-3">

    <div class="w-100">
        <div class="d-flex justify-content-between align-items-start">
            <span class="font-weight-bold">
                <?php echo e($announcement->creator->present()->name); ?>

            </span>
            <span class="text-muted">
                <?php echo e($announcement->created_at->diffForHumans(null, true, true)); ?>

            </span>
        </div>

        <a href="<?php echo e(route('announcements.show', $announcement)); ?>">
            <?php echo e($announcement->title); ?>

        </a>
    </div>
</div>
<?php /**PATH /home/doan/Workspace/PersonalWorkspace/Laravel/vanguardadmin/vendor/vanguardapp/announcements/src/../resources/views/partials/navbar/item.blade.php ENDPATH**/ ?>