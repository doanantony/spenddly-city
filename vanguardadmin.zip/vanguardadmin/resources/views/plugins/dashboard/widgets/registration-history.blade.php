<div class="card">
    <h6 class="card-header">
        @lang('Registration History')
    </h6>

    <div class="card-body">
        <div class="pt-4 px-3">
            <canvas id="myChart" height="365"></canvas>
        </div>
    </div>
</div>
