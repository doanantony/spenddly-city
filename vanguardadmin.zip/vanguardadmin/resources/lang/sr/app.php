<?php

return [
    'months' => [
        1 => 'Januar',
        2 => 'Februar',
        3 => 'Mart',
        4 => 'April',
        5 => 'Maj',
        6 => 'Jun',
        7 => 'Jul',
        8 => 'Avgust',
        9 => 'Septembar',
        10 => 'Oktobar',
        11 => 'Novembar',
        12 => 'Decembar',
    ],

    'status' => [
        'Active' => 'Aktivan',
        'Banned' => 'Banovan',
        'Unconfirmed' => 'Neverifikovan',
    ]
];
